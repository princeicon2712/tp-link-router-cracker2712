# tp-link-router-cracker
A simple dictionary attack to crack the username and password of Tp-Link Router Page
